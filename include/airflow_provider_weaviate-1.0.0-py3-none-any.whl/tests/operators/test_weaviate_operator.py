"""
Unittest module to test Operators.

Requires the unittest, pytest, and requests-mock Python libraries.

Run test:

    python3 -m unittest tests.operators.test_weaviate_operator.TestWeaviateOperator

"""

import json
import logging
import os
import pytest
from unittest import mock
from unittest import TestCase

from tempfile import NamedTemporaryFile
from pathlib import Path
import pandas as pd

from weaviate_provider.hooks.weaviate import WeaviateHook

# Import Operators
from weaviate_provider.operators.weaviate import WeaviateBackupOperator
from weaviate_provider.operators.weaviate import WeaviateImportDataOperator
from weaviate_provider.operators.weaviate import WeaviateRestoreOperator
from weaviate_provider.operators.weaviate import WeaviateCreateSchemaOperator
from weaviate_provider.operators.weaviate import WeaviateCheckSchemaOperator
from weaviate_provider.operators.weaviate import WeaviateRetrieveAllOperator

from weaviate.exceptions import UnexpectedStatusCodeException

log = logging.getLogger(__name__)

AIRFLOW_CONN_WEAVIATE_ADMIN=f'{{"conn_type": "weaviate", "host": "{os.environ["WCS_TEST_HOST"]}", "extra": {{"token": "{os.environ["WCS_TEST_KEY"]}" }} }}'
# os.environ['AIRFLOW_CONN_WEAVIATE_ADMIN'] = AIRFLOW_CONN_WEAVIATE_ADMIN

# Mock the `conn_weaviate` Airflow connection
@mock.patch.dict('os.environ', AIRFLOW_CONN_WEAVIATE_ADMIN=AIRFLOW_CONN_WEAVIATE_ADMIN)
class TestWeaviateOperator(TestCase):
    """
    Test Weaviate Operator.
    """

    # @mock.patch.dict('os.environ', AIRFLOW_CONN_WEAVIATE_USER=AIRFLOW_CONN_WEAVIATE_ADMIN)
    # def test_create_schema_operator_fail(self, m):
    #     """
    #     Test schema create failure with non-admin user. 
    #     """

    #     class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

    #     operator = WeaviateCreateSchemaOperator(
    #         task_id='create_schema_operator',
    #         weaviate_conn_id='weaviate_user',
    #         class_object_data=class_obj,
    #         existing='replace'
    #     )

    #     try:
    #         operator.execute(context={})
    #     except Exception as e:
    #         log.info(e.message)
            
    #         # Assert the API call returns expected mocked payload
    #         assert isinstance(e, UnexpectedStatusCodeException) and 'forbidden: user' in e.message
    
    def test_create_schema_operator_from_file(self):
        """
        Test schema create from file.
        """

        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        with NamedTemporaryFile(suffix='.json') as tf:
            tf.name
            
            _ = Path(tf.name).write_text(class_obj)
            # json.loads(Path(tf.name).read_text())

            operator = WeaviateCreateSchemaOperator(
                task_id='create_schema_operator',
                weaviate_conn_id='weaviate_admin',
                class_object_data='file://'+tf.name,
                existing='replace'
            )

            try:
                response = operator.execute(context={})
            except Exception as e:
                log.info(e.message)
                
                # Assert the API call returns expected mocked payload

                assert response == list(json.dumps(class_obj))
    
    def test_create_schema_operator_success(self):
        """
        Test schema create success with admin user. 
        """

        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        operator = WeaviateCreateSchemaOperator(
            task_id='create_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
            existing='replace'
        )

        try:
            response = operator.execute(context={})
        except Exception as e:
            log.info(e.message)
            
            # Assert the API call returns expected mocked payload

            assert response == list(json.dumps(class_obj))
    
    def test_create_schema_operator_exists(self):
        """
        Test schema create failure with admin user when schema exists. 
        """

        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        operator = WeaviateCreateSchemaOperator(
            task_id='create_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
            existing='fail'
        )

        try:
            response = operator.execute(context={})
        except Exception as e:
            log.info(e)
            
            # Assert the API call returns expected mocked payload

            assert 'Trying to create class Article but this class already exists.' in e.args

    def test_check_schema_operator_fail(self):
        """
        Test check schema when none exists.
        """

        WeaviateHook('weaviate_admin').get_conn().schema.delete_all()

        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        operator = WeaviateCheckSchemaOperator(
            task_id='check_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
        )

        response = operator.execute(context={})

        assert response == False

    def test_check_schema_operator_success(self):
        """
        Test schema check success
        """

        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        response = WeaviateCreateSchemaOperator(
            task_id='create_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
            existing='replace'
        ).execute(context={})

        assert json.dumps(response[0]) == class_obj

        operator = WeaviateCheckSchemaOperator(
            task_id='check_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
        )

        response = operator.execute(context={})

        assert response
    
    def test_check_schema_operator_mismatch(self):
        """
        Test schema check success
        """

        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        #create schema for test
        response = WeaviateCreateSchemaOperator(
            task_id='create_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
            existing='replace'
        ).execute(context={})

        assert json.dumps(response[0]) == class_obj

        #insert change
        class_obj = '{"class": "Article", "properties": [{"name": "TITLES_ERROR", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        operator = WeaviateCheckSchemaOperator(
            task_id='check_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
        )

        response = operator.execute(context={})

        assert response == False
    
    def test_import_operator_batch(self):
        """
        Test import data
        """

        #create schema for test
        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        response = WeaviateCreateSchemaOperator(
            task_id='create_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
            existing='replace'
        ).execute(context={})

        assert json.dumps(response[0]) == class_obj

        #insert data
        data_object = [{
            "title": "test1",
            "body": "test_body1",
            "uuid": "12345678-e64f-5d94-90db-c8cfa3fc1234",
            "vector": [0.12345] * 1536
        },
        {
            "title": "test2",
            "body": "test_body2",
            "uuid": "12345678-e64f-5d94-90db-c8cfa3fc1235",
            "vector": [0.12345] * 1536
        }]

        operator = WeaviateImportDataOperator(
            task_id='import_operator',
            weaviate_conn_id='weaviate_admin',
            class_name='Article',
            uuid_column='uuid',
            embedding_column='vector',
            data=pd.DataFrame(data_object),
            error_threshold=0,
            batched_mode=True
        )

        response = operator.execute(context={})

        assert response == []
    
    def test_import_operator_single(self):
        """
        Test import data in non-batched mode.  Also uuid will be auto generated.
        """

        #create schema for test
        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        response = WeaviateCreateSchemaOperator(
            task_id='create_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
            existing='replace'
        ).execute(context={})

        assert json.dumps(response[0]) == class_obj

        #insert data
        data_object = [{
            "title": "test1",
            "body": "test_body1",
            "uuid": "12345678-e64f-5d94-90db-c8cfa3fc1234",
            "vector": [0.12345] * 1536
        },
        {
            "title": "test2",
            "body": "test_body2",
            "uuid": "12345678-e64f-5d94-90db-c8cfa3fc1235",
            "vector": [0.12345] * 1536
        }]

        operator = WeaviateImportDataOperator(
            task_id='import_operator',
            weaviate_conn_id='weaviate_admin',
            class_name='Article',
            # uuid_column='uuid',
            embedding_column='vector',
            data=pd.DataFrame(data_object),
            error_threshold=0,
            batched_mode=False
        )

        response = operator.execute(context={})

        assert response == []
    
    def test_retrieve_operator_parquet(self):
        """
        Test retrieve data to parquet file after import
        """

        #create schema for test
        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        data_object = [{
            "title": "test1",
            "body": "test_body1",
            "uuid": "12345678-e64f-5d94-90db-c8cfa3fc1234",
            "vector": [0.12345] * 1536
        },
        {
            "title": "test2",
            "body": "test_body2",
            "uuid": "12345678-e64f-5d94-90db-c8cfa3fc1235",
            "vector": [0.12345] * 1536
        }]

        #create schema
        response = WeaviateCreateSchemaOperator(
            task_id='create_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
            existing='replace'
        ).execute(context={})

        assert json.dumps(response[0]) == class_obj

        #insert data
        response = WeaviateImportDataOperator(
            task_id='import_operator',
            weaviate_conn_id='weaviate_admin',
            class_name='Article',
            uuid_column='uuid',
            embedding_column='vector',
            data=pd.DataFrame(data_object),
            error_threshold=0,
            batched_mode=False
        ).execute(context={})

        assert response == []

        with NamedTemporaryFile(suffix='.parquet') as tf:
            operator = WeaviateRetrieveAllOperator(
                task_id='retrieve_operator',
                weaviate_conn_id='weaviate_admin',
                class_name='Article',
                output_file='file://'+tf.name,
                replace_existing=True,
            )

            response = operator.execute(context={})

            column_list = ["body", "title", "vector", "uuid"]

            read_data_objects = pd.read_parquet(tf.name).rename({'id':'uuid'}, axis=1)

            assert read_data_objects[column_list].to_json() == pd.DataFrame(data_object)[column_list].to_json()

    def test_retrieve_operator_json(self):
        """
        Test retrieve data to json file after import
        """

        #create schema for test
        class_obj = '{"class": "Article", "properties": [{"name": "title", "dataType": ["text"]}, {"name": "body", "dataType": ["text"]}]}'

        data_object = [{
            "title": "test1",
            "body": "test_body1",
            "uuid": "12345678-e64f-5d94-90db-c8cfa3fc1234",
            "vector": [0.12345] * 1536
        },
        {
            "title": "test2",
            "body": "test_body2",
            "uuid": "12345678-e64f-5d94-90db-c8cfa3fc1235",
            "vector": [0.12345] * 1536
        }]

        #create schema
        response = WeaviateCreateSchemaOperator(
            task_id='create_schema_operator',
            weaviate_conn_id='weaviate_admin',
            class_object_data=class_obj,
            existing='replace'
        ).execute(context={})

        assert json.dumps(response[0]) == class_obj

        #insert data
        response = WeaviateImportDataOperator(
            task_id='import_operator',
            weaviate_conn_id='weaviate_admin',
            class_name='Article',
            uuid_column='uuid',
            embedding_column='vector',
            data=pd.DataFrame(data_object),
            error_threshold=0,
            batched_mode=False
        ).execute(context={})

        assert response == []

        with NamedTemporaryFile(suffix='.json') as tf:
            operator = WeaviateRetrieveAllOperator(
                task_id='retrieve_operator',
                weaviate_conn_id='weaviate_admin',
                class_name='Article',
                output_file='file://'+tf.name,
                with_vector=False,
                replace_existing=True,
            )

            response = operator.execute(context={})

            column_list = ["body", "title", "vector", "uuid"]

            read_data_objects = Path(tf.name).read_text()

            original_data_objects = pd.DataFrame(data_object)[column_list]\
                                        .drop(['vector'], axis=1)\
                                        .rename({'uuid':'id'}, axis=1)\
                                        .to_json()

            assert json.loads(read_data_objects) == json.loads(original_data_objects)