import asyncio
from airflow.triggers.base import BaseTrigger, TriggerEvent
from airflow.exceptions import AirflowException

from weaviate_provider.hooks.weaviate import WeaviateHook

class WeaviateBackupTrigger(BaseTrigger):

    def __init__(self, 
                 weaviate_conn_id:str, 
                 task_id:str, 
                 backend:str, 
                 id:str,
                 ):
        super().__init__()
        self.weaviate_conn_id = weaviate_conn_id
        self.task_id = task_id
        self.backend = backend
        self.id = id

    def serialize(self):
        return ("weaviate_provider.triggers.weaviate.WeaviateBackupTrigger", 
                {"weaviate_conn_id": self.weaviate_conn_id,
                 "task_id": self.task_id,
                 "backend":self.backend,
                 "id":self.id,
                 })

    async def run(self):
        client = WeaviateHook(self.weaviate_conn_id).get_conn()

        response = client.backup.get_create_status(backend=self.backend, 
                                                   backup_id=self.id)

        while response['status'] != 'SUCCESS':
            await asyncio.sleep(1)
            response = client.backup.get_create_status(backend=self.backend, 
                                                       backup_id=self.id)
            if response['status'] == 'FAILED':
                raise AirflowException(f"Backup failed with error {response}")
            
        yield TriggerEvent(response)

class WeaviateRestoreTrigger(BaseTrigger):

    def __init__(self, 
                 weaviate_conn_id:str, 
                 task_id:str, 
                 backend:str, 
                 id:str,
                 ):
        super().__init__()
        self.weaviate_conn_id = weaviate_conn_id
        self.task_id = task_id
        self.backend = backend
        self.id = id

    def serialize(self):
        return ("weaviate_provider.triggers.weaviate.WeaviateRestoreTrigger", 
                {"weaviate_conn_id": self.weaviate_conn_id,
                 "task_id": self.task_id,
                 "backend":self.backend,
                 "id":self.id,
                 })

    async def run(self):
        client = WeaviateHook(self.weaviate_conn_id).get_conn()

        response = client.backup.get_restore_status(backend=self.backend, 
                                                            backup_id=self.id)

        while response['status'] != 'SUCCESS':
            await asyncio.sleep(1)
            response = client.backup.get_restore_status(backend=self.backend, 
                                                            backup_id=self.id)
            if response['status'] == 'FAILED':
                raise AirflowException(f"Restore failed with error {response}")
            
        yield TriggerEvent(response)