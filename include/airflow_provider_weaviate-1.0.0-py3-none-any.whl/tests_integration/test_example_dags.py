from __future__ import annotations

from pathlib import Path
import logging
import pytest
import sys
from airflow.models.dagbag import DagBag
from airflow.utils.db import create_default_connections
from airflow.utils.session import provide_session
from packaging.version import Version
# from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from datetime import datetime
from typing import Any

from airflow.configuration import secrets_backend_list
from airflow.models.dagrun import DagRun
from airflow.secrets.local_filesystem import LocalFilesystemBackend
from airflow.utils import timezone
from airflow.utils.session import NEW_SESSION, provide_session
from airflow.utils.state import DagRunState, State
from airflow.utils.types import DagRunType
from sqlalchemy.orm.session import Session
from airflow.exceptions import AirflowSkipException

log = logging.getLogger(__name__)

# from .sql.operators import utils as test_utils

# RETRY_ON_EXCEPTIONS = []
# try:
#     from google.api_core.exceptions import Forbidden, TooManyRequests
#     from pandas_gbq.exceptions import GenericGBQException

#     RETRY_ON_EXCEPTIONS.extend([Forbidden, TooManyRequests, GenericGBQException])
# except ModuleNotFoundError:
#     pass


# @retry(
#     stop=stop_after_attempt(3),
#     retry=retry_if_exception_type(tuple(RETRY_ON_EXCEPTIONS)),
#     wait=wait_exponential(multiplier=10, min=10, max=60),  # values in seconds
# )
# def wrapper_run_dag(dag):
#     test_utils.run_dag(dag)

@provide_session
def test_dag(
    dag,
    execution_date: datetime | None = None,
    run_conf: dict[str, Any] | None = None,
    conn_file_path: str | None = None,
    variable_file_path: str | None = None,
    session: Session = NEW_SESSION,
) -> DagRun:
    """
    Execute one single DagRun for a given DAG and execution date.

    :param execution_date: execution date for the DAG run
    :param run_conf: configuration to pass to newly created dagrun
    :param conn_file_path: file path to a connection file in either yaml or json
    :param variable_file_path: file path to a variable file in either yaml or json
    :param session: database connection (optional)
    """

    execution_date = execution_date or timezone.utcnow()
    dag.log.debug("Clearing existing task instances for execution date %s", execution_date)
    dag.clear(
        start_date=execution_date,
        end_date=execution_date,
        dag_run_state=False,  # type: ignore
        session=session,
    )
    dag.log.debug("Getting dagrun for dag %s", dag.dag_id)
    # dr: DagRun = _get_or_create_dagrun(
    #     dag=dag,
    #     start_date=execution_date,
    #     execution_date=execution_date,
    #     run_id=DagRun.generate_run_id(DagRunType.MANUAL, execution_date),
    #     session=session,
    #     conf=run_conf,
    # )
    log.info("dagrun id: %s", dag.dag_id)
    dr: DagRun = (
        session.query(DagRun)
        .filter(DagRun.dag_id == dag.dag_id, DagRun.execution_date == execution_date)
        .first()
    )
    if dr:
        session.delete(dr)
        session.commit()
    dr = dag.create_dagrun(
        state=DagRunState.RUNNING,
        execution_date=execution_date,
        run_id=DagRun.generate_run_id(DagRunType.MANUAL, execution_date),
        start_date=execution_date,
        session=session,
        conf=run_conf,  # type: ignore
    )
    log.info("created dagrun %s", str(dr))

    tasks = dag.task_dict
    dag.log.debug("starting dagrun")
    # Instead of starting a scheduler, we run the minimal loop possible to check
    # for task readiness and dependency management. This is notably faster
    # than creating a BackfillJob and allows us to surface logs to the user
    while dr.state == State.RUNNING:
        schedulable_tis, _ = dr.update_state(session=session)
        for ti in schedulable_tis:
            ti.start_date = timezone.utcnow()
            session.add(ti)
        session.flush()
        for ti in schedulable_tis:
            # add_logger_if_needed(dag, ti)
            logging_format = logging.Formatter("[%(asctime)s] {%(filename)s:%(lineno)d} %(levelname)s - %(message)s")
            handler = logging.StreamHandler(sys.stdout)
            handler.level = logging.INFO
            handler.setFormatter(logging_format)
            # only add log handler once
            if not any(isinstance(h, logging.StreamHandler) for h in ti.log.handlers):
                dag.log.debug("Adding Streamhandler to taskinstance %s", ti.task_id)
                ti.log.addHandler(handler)
            ti.task = tasks[ti.task_id]

            # _run_task(ti, session=session)
            log.info("*****************************************************")
            if hasattr(ti, "map_index") and ti.map_index > 0:
                log.info("Running task %s index %d", ti.task_id, ti.map_index)
            else:
                log.info("Running task %s", ti.task_id)
            try:
                ti._run_raw_task(session=session)
                session.add(ti)
                session.flush()
                log.info("%s ran successfully!", ti.task_id)
            except AirflowSkipException:
                log.info("Task Skipped, continuing")
            # except AstroCleanupException:
            #     ti.set_state(state=None)
            #     # Once the exception is raised the cleanup operator is set to FAILED state,
            #     # because of which the cleanup operator was not executed at the end.
            #     session.flush()
            #     log.info("aql.cleanup async, continuing", exc_info=True)
            log.info("*****************************************************")

    if conn_file_path or variable_file_path:
        # Remove the local variables we have added to the secrets_backend_list
        secrets_backend_list.pop(0)

    if conn_file_path or variable_file_path:
        local_secrets = LocalFilesystemBackend(
            variables_file_path=variable_file_path, connections_file_path=conn_file_path
        )
        secrets_backend_list.insert(0, local_secrets)

    return dr


@provide_session
def get_session(session=None):  # skipcq: PYL-W0621
    create_default_connections(session)
    return session


@pytest.fixture()
def session():
    return get_session()


# MIN_VER_DAG_FILE: dict[str, list[str]] = {
#     "2.3": ["example_dynamic_task_template.py", "example_bigquery_dynamic_map_task.py"],
#     "2.4": ["example_datasets.py"],
#     "2.6.1": ["calculate_popular_movies_by_genre.py"],
# }

# # Sort descending based on Versions and convert string to an actual version
# MIN_VER_DAG_FILE_VER: dict[Version, list[str]] = {
#     Version(version): MIN_VER_DAG_FILE[version]
#     for version in sorted(MIN_VER_DAG_FILE, key=Version, reverse=True)
# }


def get_dag_bag() -> DagBag:
    """Create a DagBag by adding the files that are not supported to .airflowignore"""
    example_dags_dir = Path(__file__).parent.parent / "example_dags"
    # airflow_ignore_file = example_dags_dir / ".airflowignore"

    # with open(airflow_ignore_file, "w+") as file:
    #     for min_version, files in MIN_VER_DAG_FILE_VER.items():
    #         if Version(airflow.__version__) < min_version:
    #             print(f"Adding {files} to .airflowignore")
    #             file.writelines([f"{file}\n" for file in files])

    # print(".airflowignore contents: ")
    # print(airflow_ignore_file.read_text())
    db = DagBag(example_dags_dir, include_examples=False)
    assert db.dags
    assert not db.import_errors
    return db


# PRE_DEFINED_ORDER = [
#     "example_dataset_producer",
#     "example_dataset_consumer",
# ]


# def order(dag_id: str) -> int:
#     if dag_id in PRE_DEFINED_ORDER:
#         return PRE_DEFINED_ORDER.index(dag_id)
#     return -1


dag_bag = get_dag_bag()


@pytest.mark.parametrize("dag_id") #, sorted(dag_bag.dag_ids, key=order))
def test_example_dag(session, dag_id: str):  # skipcq: PYL-W0613, PYL-W0621
    dag = dag_bag.get_dag(dag_id)
    # wrapper_run_dag(dag)
    test_dag(dag)
